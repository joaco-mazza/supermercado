"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { ChevronLeft, ChevronRight } from "lucide-react"

const productos = [
  { id: "acelga", nombre: "Acelga", precio: 15.5 },
  { id: "calabaza", nombre: "Calabaza", precio: 12.3 },
  { id: "calabacin", nombre: "Calabacín", precio: 18.75 },
  { id: "lechuga", nombre: "Lechuga", precio: 14.2 },
  { id: "lechuga-arrepollada", nombre: "Lechuga Arrepollada", precio: 16.8 },
  { id: "repollo", nombre: "Repollo", precio: 11.9 },
  { id: "pepino", nombre: "Pepino", precio: 13.45 },
  { id: "pimiento-amarillo", nombre: "Pimiento Amarillo", precio: 22.6 },
  { id: "pimiento-rojo", nombre: "Pimiento Rojo", precio: 24.3 },
  { id: "pimiento-verde", nombre: "Pimiento Verde", precio: 20.15 },
  { id: "manzana", nombre: "Manzana", precio: 19.8 },
  { id: "naranja-comun", nombre: "Naranja Común", precio: 8.9 },
  { id: "naranja-jugo", nombre: "Naranja Jugo", precio: 9.5 },
  { id: "tomate-ensalada", nombre: "Tomate Ensalada", precio: 17.25 },
  { id: "tomate-perita", nombre: "Tomate Perita", precio: 16.4 },
  { id: "zanahoria", nombre: "Zanahoria", precio: 10.75 },
  { id: "zapallo-criollo", nombre: "Zapallo Criollo", precio: 7.8 },
  { id: "zapallo-ingles", nombre: "Zapallo Inglés", precio: 8.9 },
  { id: "zapallito-verde", nombre: "Zapallito Verde", precio: 15.6 },
  { id: "zucchini", nombre: "Zucchini", precio: 18.3 },
]

export default function SupermercadoVPP() {
  const [encargado, setEncargado] = useState("PEREYRA, MATIAS EDUARDO")
  const [sector, setSector] = useState("VERDURAS")
  const [productoSeleccionado, setProductoSeleccionado] = useState(productos[0])
  const [balanza, setBalanza] = useState("0.500")
  const [paginaActual, setPaginaActual] = useState(0)

  const productosPorPagina = 20
  const totalPaginas = Math.ceil(productos.length / productosPorPagina)
  const productosVisibles = productos.slice(paginaActual * productosPorPagina, (paginaActual + 1) * productosPorPagina)

  const calcularTotal = () => {
    const peso = Number.parseFloat(balanza) || 0
    return (productoSeleccionado.precio * peso).toFixed(2)
  }

  const manejarSeleccionProducto = (producto: (typeof productos)[0]) => {
    setProductoSeleccionado(producto)
  }

  const imprimirTicket = () => {
    alert("Imprimiendo ticket...")
  }

  const cancelar = () => {
    setProductoSeleccionado(productos[0])
    setBalanza("0.500")
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-6xl mx-auto bg-white rounded-lg border-2 border-gray-400 p-6">
        {/* Header */}
        <h1 className="text-lg font-semibold mb-4">Ventas por peso (VPP)</h1>

        {/* Dropdowns */}
        <div className="flex gap-8 mb-6">
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">Encargado:</label>
            <Select value={encargado} onValueChange={setEncargado}>
              <SelectTrigger className="w-64 bg-gray-100">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="PEREYRA, MATIAS EDUARDO">PEREYRA, MATIAS EDUARDO</SelectItem>
                <SelectItem value="GARCIA, JUAN CARLOS">GARCIA, JUAN CARLOS</SelectItem>
                <SelectItem value="RODRIGUEZ, MARIA ELENA">RODRIGUEZ, MARIA ELENA</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">Sector:</label>
            <Select value={sector} onValueChange={setSector}>
              <SelectTrigger className="w-32 bg-gray-100">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="VERDURAS">VERDURAS</SelectItem>
                <SelectItem value="FRUTAS">FRUTAS</SelectItem>
                <SelectItem value="CARNES">CARNES</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-6">
          {/* Grid de productos */}
          <div className="flex-1">
            <div className="grid grid-cols-5 gap-2 mb-4">
              {productosVisibles.map((producto) => (
                <Button
                  key={producto.id}
                  variant={productoSeleccionado.id === producto.id ? "default" : "outline"}
                  className={`h-16 text-xs font-medium ${
                    productoSeleccionado.id === producto.id
                      ? "bg-cyan-400 hover:bg-cyan-500 text-black"
                      : "bg-gray-200 hover:bg-gray-300 text-black border-gray-400"
                  }`}
                  onClick={() => manejarSeleccionProducto(producto)}
                >
                  {producto.nombre}
                </Button>
              ))}
            </div>

            {/* Controles de navegación */}
            <div className="flex items-center justify-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPaginaActual(Math.max(0, paginaActual - 1))}
                disabled={paginaActual === 0}
                className="bg-gray-200 border-gray-400"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>

              <div className="flex gap-1">
                {Array.from({ length: totalPaginas }, (_, i) => (
                  <div key={i} className={`w-2 h-6 ${i === paginaActual ? "bg-gray-600" : "bg-gray-300"}`} />
                ))}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setPaginaActual(Math.min(totalPaginas - 1, paginaActual + 1))}
                disabled={paginaActual === totalPaginas - 1}
                className="bg-gray-200 border-gray-400"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Panel de datos del producto */}
          <div className="w-64">
            <div className="border-2 border-gray-400 rounded p-4 mb-4">
              <h3 className="text-sm font-medium mb-3">Datos de Producto</h3>

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <label className="text-sm w-16">Producto:</label>
                  <Input
                    value={productoSeleccionado.nombre.toUpperCase()}
                    readOnly
                    className="text-xs bg-white border-gray-400"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <label className="text-sm w-16">Precio x kg:</label>
                  <Input
                    value={productoSeleccionado.precio.toFixed(2)}
                    readOnly
                    className="text-xs bg-white border-gray-400"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <label className="text-sm w-16">Balanza (kg):</label>
                  <Input
                    value={balanza}
                    onChange={(e) => setBalanza(e.target.value)}
                    className="text-xs bg-white border-gray-400"
                    type="number"
                    step="0.001"
                  />
                </div>
              </div>

              <div className="mt-6 p-4 bg-gray-100 rounded text-center">
                <div className="text-sm text-gray-600 mb-1">Total ($):</div>
                <div className="text-2xl font-bold">{calcularTotal()}</div>
              </div>
            </div>

            {/* Botones */}
            <div className="space-y-2">
              <Button
                onClick={imprimirTicket}
                className="w-full bg-gray-200 hover:bg-gray-300 text-black border-2 border-gray-400"
                variant="outline"
              >
                Imprimir Ticket
              </Button>
              <Button
                onClick={cancelar}
                className="w-full bg-gray-200 hover:bg-gray-300 text-black border-2 border-gray-400"
                variant="outline"
              >
                Cancelar
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
